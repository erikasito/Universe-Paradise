import SwiftUI
import AVFoundation

class superStarShow8: ObservableObject {
    @Published var isStarsOn:   Bool = false
}




struct Scene8: View {
    
    var backgrounds:[String] = ["stars1", "stars2"]
    
    
    @State var launchYCoordinate: CGFloat = 50
    @State var launchXCoordinate: CGFloat = 400
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    
    let imageSwitchTimer = Timer.publish(every:13, on: .main, in: .common) 
        .autoconnect()
    
    @State var showingStars: Bool = false
    @State var gamePlay = false
    
    @State private var imageChange = false
    @State private var moveY = false
    
    let texts: [String] = [
        "Thus, Andrea begins alone to observe the sky. Suddenly, Andrea notices something different in the firmament:...", "It is Blue on a super-sonic rocket that whizzes by smiling among the stars and the colors of the fireworks (click the mushroom on the right to go on...)"
    ]
    
    
    
    @State var currentText: Int = 0
    @Binding var scene: Int
    
    public var body: some View {
        
        ZStack {
            
            
            Image(uiImage: UIImage(named: "8")!)
                .resizable()
            
            Stars2(showingStars: $showingStars)
            
            Fireworks(showingStars: $showingStars)
            
            missile2(showingStars: $showingStars)
            
            Fire(showingStars: $showingStars)
            
            Text(texts[currentText])
                .foregroundColor(Color.black)
                .font(.custom("Pixeboy", size: 20))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
                .border(.black, width: 2)
                .background(.white.opacity(0.85))
                .lineSpacing(2)
                .offset(x: 0, y: moveY ? 350 : 1500)
        }
        .onTapGesture {
            withAnimation(.easeInOut) {
                scene += 1
            }
        }
        .onAppear {
            
            
            withAnimation(.easeInOut) {
                moveY.toggle()
            }
            
            for i in 0..<texts.count{
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(7 * i)) {
                    withAnimation(.easeInOut) {
                        currentText = i
                    }
                }
            }
        }
    }
}











