
import SwiftUI
import AVFoundation



struct missile: View {
    @State var launchYCoordinate: CGFloat = 80
    @State var launchXCoordinate: CGFloat = 420
    @State var activeImageIndex = 0 // Index of the currently displayed image
    @State var audioPlayer: AVAudioPlayer?
    //@Binding var showingMissile: Bool
    @State var gamePlay = false
    @Binding var showingStars: Bool
    
    
    
    var body: some View {
        
        ZStack{
            Image(uiImage: UIImage(named: "missile")!)
                .resizable()
                .offset(x: launchXCoordinate, y: launchYCoordinate)
                .onAppear(){
                    withAnimation(.linear(duration: 5).repeatForever(autoreverses: false)){
                        launchXCoordinate = -2000
                        launchYCoordinate = -700
                    }
                }
          
                    .onAppear(perform: playSoundScene1)
        }
        .sheet(isPresented: $gamePlay)
        {
            
        }
    }
}




