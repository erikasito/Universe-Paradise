
import AVFoundation

var player: AVAudioPlayer?


public func playSoundScene1() {
    guard let path = Bundle.main.path(forResource: "missile_launch", ofType:"mp3") else {
        return }
    let url = URL(fileURLWithPath: path)
    
    do {
        player = try AVAudioPlayer(contentsOf: url)
        player?.play()
        
    } catch let error {
        print(error.localizedDescription)
    }
}





