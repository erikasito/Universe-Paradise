import SwiftUI
import AVFoundation




struct Fireworks: View {
    
    @State var opacità : Bool = false
    @Binding var showingStars: Bool
    @State var gamePlay = false
    
    var body: some View {
        ZStack{
                Image(uiImage: UIImage(named: "fireworks1")!)
                    .resizable()
                    .opacity(opacità ? 0.9 : 0)
                    
                            
                            Image(uiImage: UIImage(named: "fireworks2")!)
                                .resizable()
                                .opacity(opacità ? 0.7 : 0)
                            
                            
                                .onAppear(){
                                    withAnimation(.linear(duration: 5).repeatForever(autoreverses: true)){
                                        opacità = true
                        }
                    }
            }
        .onAppear(perform: playFireworks)
                    }
        }
            
            
        
        
