import AVFoundation
import SwiftUI



class AudioManager {
    
    var audioPlayer: AVAudioPlayer?
    
    private init() {}
    
    static let main = AudioManager()
    
    func playAudio(sound: String, type: String) {
        if let player = self.audioPlayer {
            if player.isPlaying {
                player.stop()
            }
        }
        
        if let audioURL =  Bundle.main.url(forResource: sound, withExtension: type){
            do {
                try self.audioPlayer = AVAudioPlayer(contentsOf: audioURL)
                self.audioPlayer?.numberOfLoops = 1000
                self.audioPlayer?.play()
                
            } catch {
                print("Couldn't play audio. Error: \(error)")
            }
        } else {
            
            print("No audio file found")
        }
    }
    
}
