
import SwiftUI
import AVFoundation


struct Fire: View {
    @State var gamePlay = false
    @State var fireFrames: [String] = ["Fire1", "Fire2"]
    @State var activeImageIndex = 0 // Index of the currently displayed image
    @Binding var showingStars: Bool
    
    
    let imageSwitchTimer = Timer.publish(every:2, on: .main, in: .common)
        .autoconnect()
    @State var activeFireIndex = 0
    let fireFramesTimer = Timer.publish(every: 0.13, on: .main, in: .common)
        .autoconnect()
    @State private var imageChange = false
    @State private var moveY = false
    @State private var offFireY = false
    
    
    var body: some View {
        
        ZStack{
            
            
            Image(uiImage: UIImage(named: fireFrames[activeFireIndex])!)
                .resizable()
                .offset(y: offFireY ? 0 : 1)
            
                .zIndex(1000000)
            
                .onReceive(fireFramesTimer) { _ in
                    self.activeFireIndex = (self.activeFireIndex + 1) % 2
                    withAnimation(.easeIn(duration: 2).delay(0)) {
                        fireFrames = ["Fire1", "Fire2"]
                        activeImageIndex = 0
                        imageChange = false
                        moveY = false
                        offFireY = false
                    }
                }
            
            
        }
        .zIndex(100000)
        .sheet(isPresented: $gamePlay)
        {
            //Scene1()
            
        }
    }
}

