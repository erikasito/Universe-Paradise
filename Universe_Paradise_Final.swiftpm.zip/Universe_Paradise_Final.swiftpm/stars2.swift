import SwiftUI


struct Stars2: View {
    @State var gamePlay = false
    @State var starsFrames: [String] = ["stars3", "stars4"]
    @State var activeImageIndex = 0 // Index of the currently displayed image
    @Binding var showingStars: Bool
    
    
    let imageSwitchTimer = Timer.publish(every:2, on: .main, in: .common)
        .autoconnect()
    @State var activeStarsIndex = 0
    let starsFramesTimer = Timer.publish(every: 0.13, on: .main, in: .common)
        .autoconnect()
    @State private var imageChange = false
    @State private var moveY = false
    @State private var offStarsY = false
    
    
    var body: some View {
        
        ZStack{
            
            
            Image(uiImage: UIImage(named: starsFrames[activeStarsIndex])!)
                .resizable()
                .offset(y: offStarsY ? 0 : 1)
            
                .zIndex(1000000)
            
                .onReceive(starsFramesTimer) { _ in
                    self.activeStarsIndex = (self.activeStarsIndex + 1) % 2
                    withAnimation(.easeIn(duration: 2).delay(0)) {
                        starsFrames = ["stars3", "stars4"]
                        activeImageIndex = 0
                        imageChange = false
                        moveY = false
                        offStarsY = false
                    }
                }
            
            
        }
        .zIndex(100000)
        .sheet(isPresented: $gamePlay)
        {
            //Scene1()
            
        }
    }
}

