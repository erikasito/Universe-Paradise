import SwiftUI
import AVFoundation


class superStarShow3: ObservableObject {
    @Published var isStarsOn:   Bool = false
}




struct Scene3: View {
    
    var backgrounds:[String] = ["stars1", "stars2"]
    
    
    @State var launchYCoordinate: CGFloat = 50
    @State var launchXCoordinate: CGFloat = 400
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    
    let imageSwitchTimer = Timer.publish(every:13, on: .main, in: .common)
        .autoconnect()
    
    @State var showingStars: Bool = false
    @State var gamePlay = false
    
    @State private var imageChange = false
    @State private var moveY = false
    
    let texts: [String] = [
        "From there, Blue begins to analyze it and he realizes he can explore the world through internet with his new special 'navigator'!", "Thus, Blue begins to deepen his knowledge of astronomy and to dream even bigger. (click the mushroom on the right to go on...)"
    ]
    
    @State var currentText: Int = 0
    @Binding var scene: Int
    
    public var body: some View {
        
        ZStack {
            
            
            Image(uiImage: UIImage(named: "3")!)
                .resizable()
            
            Stars(showingStars: $showingStars)
            
            
            missile(showingStars: $showingStars)
            
            
            Text(texts[currentText])
                .foregroundColor(Color.black)
                .font(.custom("Pixeboy", size: 20))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
                .border(.black, width: 2)
                .background(.white.opacity(0.85))
                .lineSpacing(2)
                .offset(x: 0, y: moveY ? 350 : 1500)
        }
        
        .onAppear {
            
            
            withAnimation(.easeInOut) {
                moveY.toggle()
            }
            
            for i in 0..<texts.count{
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(7 * i)) {
                    withAnimation(.easeInOut) {
                        currentText = i
                    }
                }
            }
        }
    }
}









