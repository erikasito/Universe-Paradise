
import AVFoundation

var player2: AVAudioPlayer?

public func playFireworks() {
    guard let path = Bundle.main.path(forResource: "Fireworks", ofType:"mp3") else {
        return }
    let url = URL(fileURLWithPath: path)
    
    do {
        player2 = try AVAudioPlayer(contentsOf: url)
        player2?.play()
        
    } catch let error {
        print(error.localizedDescription)
    }
}


