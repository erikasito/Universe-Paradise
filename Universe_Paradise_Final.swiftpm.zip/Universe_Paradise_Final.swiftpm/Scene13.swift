import SwiftUI
import AVFoundation

class superStarsShow13: ObservableObject {
    @Published var isStarsOn:   Bool = false
}


struct Scene13: View {
    
    @Binding var scene: Int
    
    var backgrounds:[String] = ["stars1", "stars2"]
    
    
    @State var launchYCoordinate: CGFloat = 50
    @State var launchXCoordinate: CGFloat = 400
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    let imageSwitchTimer = Timer.publish(every:13, on: .main, in: .common)
        .autoconnect()
    
    @State var showingStars: Bool = false
    
    @State var gamePlay = false
    
    @State private var imageChange = false
    @State private var moveY = false
    
    let texts: [String] = [
        "Love, sharing, positivity, dreaming are contagious things, which are transmitted and which allow you to build unimaginable and fantastic realities, so beautiful, that they cannot even be destroyed by war!", "Look at the sky, make a wish and believe in it! (End)"
    ]
    
    @State var currentText: Int = 0
    
    
    
    public var body: some View {
        ZStack{
            
            Stars(showingStars: $showingStars)
            
            Image(uiImage: UIImage(named: "13")!)
                .resizable()
            
            Fireworks(showingStars: $showingStars)
            
            missile(showingStars: $showingStars)
            
            
            
            
            Text(texts[currentText])
                .foregroundColor(Color.black)
                .font(.custom("Pixeboy", size: 20))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
                .border(.black, width: 2)
                .background(.white.opacity(0.85))
                .lineSpacing(2)
                .offset(x: 0, y: moveY ? 350 : 1500)
            
        }
        .onAppear {
            
            //AudioManager.main.playAudio(sound: "universe_paradise", type: "mp3")
            
            withAnimation(.easeInOut) {
                moveY.toggle()
            }
            
            for i in 0..<texts.count{
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(10 * i)) {
                    withAnimation(.easeInOut) {
                        currentText = i
                    }
                }
            }
        }
        
        
        
    }}






