import SwiftUI
import AVFoundation

class superStarsShow0: ObservableObject {
    @Published var isStarsOn:   Bool = false
}




struct Home: View {
    
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    let imageSwitchTimer = Timer.publish(every:13, on: .main, in: .common)
        .autoconnect()
    
    @Binding var scene: Int
    
    var backgrounds:[String] = ["stars1", "stars2"]
    
    @State private var moveY = false
    @State var launchYCoordinate: CGFloat = 50
    @State var launchXCoordinate: CGFloat = 400
    
    @State var showingStars: Bool = false
    @State var gamePlay = false
    
    @State var currentText: Int = 0
    
    @State var multiColor = false
    
    let texts: [String] = [
        "Universe Paradise"
    ]
    
    let texts2: [String] = [
        "Blue's Dream",
    ]
    
    let texts3: [String] = [
        "Dreamed and created by Erika Sito"
    ]
    
    let texts4: [String] = [
        "(Click the mushroom on the right to start...)"
    ]
    
    
    
    
    public var body: some View {
        ZStack{
            
            
                Image(uiImage: UIImage(named: "Home")!)
                    .resizable()
                
            Toggle(isOn: $multiColor, label: {
                Text("Enable Multi Colors")
                    .foregroundColor(Color.white)
                    .font(.custom("Pixeboy", size: 30))
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
            }
            )
                .padding(max(300, 0))
                .lineSpacing(2)
                .offset(x: 20, y: moveY ? 310 : 1400)
                
            //missile(showingStars: $showingStars)
                
            TextShimmer(text: texts[currentText], multiColors: $multiColor)
                .offset(x: 0, y: moveY ? -60 : 1400)
                .padding()
                .ignoresSafeArea()
            
            
            Text(texts2[currentText])
                .foregroundColor(Color.yellow)
                .font(.custom("Pixeboy", size: 50))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
            //                    .border(.black, width: 2)
                .background(.white.opacity(0))
                .lineSpacing(2)
                .offset(x: 20, y: moveY ? 40 : 1400)
            
            
            Text(texts3[currentText])
                .foregroundColor(Color.green)
                .font(.custom("Pixeboy", size: 40))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
            //                    .border(.black, width: 2)
                .background(.white.opacity(0))
                .lineSpacing(2)
                .offset(x: 20, y: moveY ? 120 : 1400)
            
            
            Text(texts4[currentText])
                .foregroundColor(Color.red)
                .font(.custom("Pixeboy", size: 30))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
            //                    .border(.black, width: 2)
                .background(.white.opacity(0))
                .lineSpacing(2)
                .offset(x: 20, y: moveY ? 200 : 1400)
                
            
            
            //Stars(showingStars: $showingStars)
            
            
        }
        .onAppear {
            
            withAnimation(.easeInOut) {
            moveY.toggle()
            }
            
            for i in 0..<texts.count{
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(5 * i)) {
                    withAnimation(.easeInOut) {
                        currentText = i
                    }
                }
            }
        }
                
                
        
    }}





struct TextShimmer: View {
    
    var text: String
    @State var animation = false
    @Binding var multiColors: Bool
    
    var body: some View{
        
        ZStack{
            
            Text(text)
                .font(.system(size: 100, weight: .bold))
                .foregroundColor(Color(UIColor(named: "lightblue")!).opacity(0.7))
                 
            
            
            
            // MultiColor Text....
            
            HStack(spacing: 0){
                
                ForEach(0..<text.count,id: \.self){index in
                    
                    Text(String(text[text.index(text.startIndex, offsetBy: index)]))
                        .font(.system(size: 110, weight: .bold))
                        .foregroundColor(multiColors ? randomColor() : Color.white)
                    
                }
            }
            // Masking For Shimmer Effect...
            .mask(
                
                Rectangle()
                // For Some More Nice Effect Were Going to use Gradient...
                    .fill(
                        
                        // You can use any Color Here...
                        LinearGradient(gradient: .init(colors: [Color.white.opacity(0.5),Color.white,Color.white.opacity(0.5)]), startPoint: .top, endPoint: .bottom)
                    )
                    .rotationEffect(.init(degrees: 110))
                    .padding(20)
                // Moving View Continously...
                // so it will create Shimmer Effect...
                    .offset(x: -250)
                    .offset(x: animation ? 500 : 0)
            )
            .onAppear(perform: {
                
                withAnimation(Animation.linear(duration: 2).repeatForever(autoreverses: false)){
                    
                    animation.toggle()
                }
            })
            
            
            
            
        }
    }
    
}
    
    // Random Color....
    
    // It's Your Wish yOu can change anything here...
    // or you can also use Array of colors to pick random One....
    
    func randomColor()->Color{
        
        let color = UIColor(red: 1, green: .random(in: 0...1), blue: .random(in: 0...1), alpha: 1)
        
        return Color(color)
    }

