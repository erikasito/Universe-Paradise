import SwiftUI
import AVFoundation


class superStarShow6: ObservableObject {
    @Published var isStarsOn:   Bool = false
}




struct Scene6: View {
    
    var backgrounds:[String] = ["stars1", "stars2"]
    
    
    @State var launchYCoordinate: CGFloat = 50
    @State var launchXCoordinate: CGFloat = 400
    @State var activeImageIndex = 0 // Index of the currently displayed image
    
    
    let imageSwitchTimer = Timer.publish(every:13, on: .main, in: .common) 
        .autoconnect()
    
    @State var showingStars: Bool = false
    @State var gamePlay = false
    
    @State private var imageChange = false
    @State private var moveY = false
    
    let texts: [String] = [
        "Thus, they begin to meet every night to admire the sky and Blue manages to pass on his passion for astronomy to his new little friend. (click the mushroom on the right to go on...)"
    ]
        
    
    
    @State var currentText: Int = 0
    @Binding var scene: Int
    
    public var body: some View {
        
        ZStack {
            
            
            Image(uiImage: UIImage(named: "6")!)
                .resizable()
            
            Stars(showingStars: $showingStars)
            
            Fireworks(showingStars: $showingStars)
            
            missile(showingStars: $showingStars)
            
            
            Text(texts[currentText])
                .foregroundColor(Color.black)
                .font(.custom("Pixeboy", size: 20))
                .fontWeight(.bold)
                .ignoresSafeArea()
                .padding()
                .border(.black, width: 2)
                .background(.white.opacity(0.85))
                .lineSpacing(2)
                .offset(x: 0, y: moveY ? 350 : 1500)
                
        }
        
        .onAppear {
            
            
            withAnimation(.easeInOut) {
                moveY.toggle()
            }
            
            for i in 0..<texts.count{
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(8 * i)) {
                    withAnimation(.easeInOut) {
                        currentText = i
                    }
                }
            }
        }
    }
}









