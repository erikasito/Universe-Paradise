import SwiftUI
import AVFoundation





struct ContentView: View {
    
    @State var scene: Int = 0
    @State var gamePlay = false

    
    var body: some View {
        
        ZStack{
            
        switch scene {
        case 0: Home(scene: $scene)
        case 1: Scene1(scene: $scene)
        case 2: Scene2(scene: $scene)
        case 3: Scene3(scene: $scene)
        case 4: Scene4(scene: $scene)
        case 5: Scene5(scene: $scene)
        case 6: Scene6(scene: $scene)
        case 7: Scene7(scene: $scene)
        case 8: Scene8(scene: $scene)
        case 9: Scene9(scene: $scene)
        case 10: Scene10(scene: $scene)
        case 11: Scene11(scene: $scene)
        case 12: Scene12(scene: $scene)
        case 13: Scene13(scene: $scene)
        default: Scene1(scene: $scene)
            
        }
            Button(){
                if (scene > 0){
                    scene -= 1
                }
                
            } label : {
                Image(uiImage: UIImage(named: "mushroom2")!)
                    .resizable()
            } 
            .frame(width: 90, height: 90)
            .offset(x: -460, y: -100)
            .padding()
            
            
            Button(){
                scene += 1
            } label : {
                Image(uiImage: UIImage(named: "mushroom1")!)
                    .resizable()
            }
            .frame(width: 90, height: 90)
            .offset(x: 460, y: -100)
            .padding()
            
    }
        .onAppear{
            AudioManager.main.playAudio(sound: "universe_paradise", type: "mp3")
            
        }
}
}
